<?php

return [
    'name' => 'Settings',
    'app_id' => 1,
    'active_layout' => 'app_screen_frest',
    'company_title' => 'Organization',
    'section_title' => 'Unit'
];
